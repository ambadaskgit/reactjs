##setup
1. Please do 'npm install'
##for executing project
2. npm start to execute project.

