import React from "react";
import data from "./data.json";
import './App.css';

function App() {
  function range(start, end) {
    return Array(end - start + 1).fill().map((_, idx) => start + idx)
  }
  const arr =  range(0, 99);
  const [max, setMax] = React.useState(9);
  const [min, setMin] = React.useState(0);
  const handleNext = () => {
    if(max < 99) {
      setMin(min + 10);
      setMax(max + 10);
    } else {
      setMin(0);
      setMax(9);
    }
  }
  const handlePrev = () => {
    if(min > 0) {
      setMin(min - 10);
      setMax(max - 10);
    } else {
      setMin(0);
      setMax(9);
    }
  }
  const getRows = () => {
    return (
      <>
       {
        arr.map((index) => {
          return (
            <>
              { index <= max && index >= min && (<tr>
                  <td>
                    {index}
                  </td>
                  <td>
                    {data.id[index]}
                  </td>
                  <td>
                    {data.title[index]}
                  </td>
                  <td>
                  {data.danceability[index]}
                  </td>
                  <td>
                  {data.energy[index]}
                  </td>
                  <td>
                  {data.mode[index]}
                  </td>
                  <td>
                  {data.acousticness[index]}
                  </td>
                  <td>
                  {data.tempo[index]}
                  </td>
                  <td>
                  {data.duration_ms[index]}
                  </td>
                  <td>
                  {data.num_sections[index]}
                  </td>
                  <td>
                  {data.num_segments[index]}
                  </td>
                </tr>)
              }
            </>
          )
        })
       }
       <>
       <div>
            <button onClick={handlePrev} disabled={min === 0}>Previous</button>
        </div>
        <div>
            <button onClick={handleNext} disabled={max === 99} > Next </button>
        </div>
       </> 
      </>
    )
  };

  return (
    <div className="App">
      <table border="1">
        <tr>
          <td>
            Index
          </td>
          <td>
            Id
          </td>
          <td>
            Title
          </td>
          <td>
            Dance Ability
          </td>
          <td>
            Energy
          </td>
          <td>
            Mode
          </td>
          <td>
            Acousticnes
          </td>
          <td>
            Tempo
          </td>
          <td>
            Duration_ms
          </td>
          <td>
            Num Sections
          </td>
          <td>
            Num Segments
          </td>
        </tr>
        {
         getRows()
        }
      </table>
     
    </div>
  );
}

export default App;
